const express = require("express");
const axios = require("axios");
const app = express();

// Configurazione
app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));

// Inserisci la tua API Key AviationStack qui ▼
const API_KEY = "e1f2a3795e1d214593e582e555bc76d1";

// Rotta principale
app.get("/", (req, res) => {
    res.render("index");
});

// Gestione ricerca volo
app.post("/search", async (req, res) => {
    const flightCode = req.body.flightCode.toUpperCase();

    try {
        const response = await axios.get(
            `http://api.aviationstack.com/v1/flights?access_key=${API_KEY}&flight_iata=${flightCode}`,
        );

        if (!response.data.data || response.data.data.length === 0) {
            return res.render("results", {
                error: "Nessun volo trovato con questo codice",
                result: null,
            });
        }

        const flightData = response.data.data[0];

        const result = {
            flightCode,
            status: flightData.flight_status,
            airline: flightData.airline.name,
            departure: {
                airport: flightData.departure.airport,
                iata: flightData.departure.iata,
                terminal: flightData.departure.terminal || "N/D",
                scheduled: new Date(
                    flightData.departure.scheduled,
                ).toLocaleString(),
            },
            arrival: {
                airport: flightData.arrival.airport,
                iata: flightData.arrival.iata,
                terminal: flightData.arrival.terminal || "N/D",
                scheduled: new Date(
                    flightData.arrival.scheduled,
                ).toLocaleString(),
                estimated: flightData.arrival.estimated
                    ? new Date(flightData.arrival.estimated).toLocaleString()
                    : "In orario",
            },
        };

        res.render("results", { result, error: null });
    } catch (error) {
        console.error("Errore:", error.message);
        res.render("results", {
            error: "Errore di connessione al servizio",
            result: null,
        });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server attivo su porta ${PORT}`));
